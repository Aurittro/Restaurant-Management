package com.dineout.code.model.kitchen.models;

import java.util.ArrayList;

public class ChefQueue {
    private ArrayList<OrderDetailsDb> dishes;
}
